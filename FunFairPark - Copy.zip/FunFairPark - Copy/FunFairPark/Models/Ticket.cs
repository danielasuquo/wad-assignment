﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FunFairPark.Models
{
    public class Ticket
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("FEventId")]
        public int TicketEventID { get; set; }
        public Event FEventId { get; set; }

        [ForeignKey("Userid")]
        public string TicketHolder { get; set; }
        public ApplicationUser Userid { get; set; }

    }
}
