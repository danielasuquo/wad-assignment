﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FunFairPark.Models
{
    public class Feedback
    {
        [Key]
        public int Id { get; set; }
        public string FeedbackText { get; set; }
        public string Stars { get; set; }
        public string Date { get; set; }

        [ForeignKey("ForeginEventId")]
        public int EventId { get; set; }
        public Event ForeginEventId { get; set; }

        [ForeignKey("Addedby")]
        public string FeedbackAddedBy { get; set; }
        public ApplicationUser Addedby { get; set; }
    }
}
