﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FunFairPark.Models
{
    public class Event
    {
        [Key]
        public int Id { get; set; }
        public string EventName { get; set; }
        public string EventLocation { get; set; }
        public string EventDescription { get; set; }
        [ForeignKey("ForeignEventtype")]
        public int EventType { get; set; }
        public EventType ForeignEventtype { get; set; }
        public string EventTotalTickets { get; set; }
        public string EventCost { get; set; }
        public string Photo { get; set; }
        [ForeignKey("EventAddedby")]
        public string EventOwner { get; set; }
        public ApplicationUser EventAddedby { get; set; }

    }
}
