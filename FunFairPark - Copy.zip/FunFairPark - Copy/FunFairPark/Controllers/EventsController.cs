﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FunFairPark.Data;
using FunFairPark.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace FunFairPark.Controllers
{
    public class EventsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EventsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public string GetUserId()
        {
            var useremail = User.Identity.Name;
            var id = _context.Users.Where(a => a.Email == useremail).FirstOrDefault();
            return id.Id;
        }

        [Authorize]
        public IActionResult Index()
        {
            var listevents = _context.Events.ToList();
            listevents.ForEach(a => a.EventAddedby = _context.ApplicationUsers.Find(a.EventOwner));
            listevents.ForEach(a => a.ForeignEventtype = _context.EventTypes.Find(a.EventType));
            return View(listevents);
        }

        [Authorize(Roles ="Admin")]
        [HttpGet]
        public IActionResult CreateEvent()
        {
            ViewBag.EventType = new SelectList(_context.EventTypes.ToList(), "Id", "TypeName"); 
            return View();
        }


        [Authorize(Roles ="Admin")]
        [HttpPost]
        public IActionResult CreateEvent(Event EventDetails)
        {
            EventDetails.EventOwner = GetUserId();
            _context.Events.Add(EventDetails);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult EditEvent(int id)
        {
            var eventtodedit = _context.Events.Find(id);
            ViewBag.EventType = new SelectList(_context.EventTypes.ToList(), "Id", "TypeName", _context.EventTypes.Find(id).Id);
            return View(eventtodedit);
        }


        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult EditEvent(Event EventDetails)
        {
            EventDetails.EventOwner = GetUserId();
            _context.Entry(EventDetails).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult DeleteEvent(int Id) 
        {
            var eventtodelete = _context.Events.Find(Id);
            eventtodelete.ForeignEventtype = _context.EventTypes.Find(eventtodelete.EventType);
            return View(eventtodelete);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult DeleteEvent(Event deleteEvent)
        {
            _context.Events.Remove(deleteEvent);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult BookEvent(string id)
        {
            var eventdetails = _context.Events.Find(Convert.ToInt32(id));
            var remainingTickets = Convert.ToInt32(eventdetails.EventTotalTickets) - 1;
            eventdetails.EventTotalTickets = remainingTickets.ToString();
            _context.Entry(eventdetails).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _context.SaveChanges();
            //booking procedure
            var ticket = new Ticket
            {
                TicketEventID = Convert.ToInt32(id),
                TicketHolder = GetUserId()
            };
            _context.Tickets.Add(ticket);
            _context.SaveChanges();
            return Ok(new { message = "Ticket Booked Successfully!" });
        }

        [Authorize]
        public IActionResult YourTickets()
        {
            var list = _context.Tickets.Where(a => a.TicketHolder == GetUserId()).ToList();
            list.ForEach(a => a.FEventId = _context.Events.Find(a.TicketEventID));
            list.ForEach(a => a.Userid = _context.ApplicationUsers.Find(a.TicketHolder));
            list.ForEach(a => a.FEventId.ForeignEventtype = _context.EventTypes.Find(a.FEventId.EventType));
            return View(list);
        }


        [HttpGet]
        public IActionResult Feedback(int Id)
        {
            ViewBag.EventId = Id;
            return View();
        }

        [HttpPost]
        public IActionResult Feedback(Feedback feedback)
        {
            feedback.Date = DateTime.Now.ToString();
            feedback.FeedbackAddedBy = GetUserId();

            _context.Feedbacks.Add(feedback);
            _context.SaveChanges();
            ViewBag.message = "Thanks for your Feedback!";
            return View();
        }
    }
}
